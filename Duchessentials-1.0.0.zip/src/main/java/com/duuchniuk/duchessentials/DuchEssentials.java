package com.duuchniuk.duchessentials;

import com.duuchniuk.duchessentials.api.DuchAPI;
import com.duuchniuk.duchessentials.core.DuchLogger;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DuchEssentials implements ModInitializer {
    public static final String MODID = "duchessentials";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    @Override
    public void onInitialize() {
        DuchLogger.info("DuchEssentials v" + VERSION + " initialized");
        DuchAPI.registerMod(MODID, "DuchEssentials", VERSION, "Duuchniuk", "Library mod with utilities for other mods");
    }
}
