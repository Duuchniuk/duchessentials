package com.duuchniuk.duchessentials.core;

import com.duuchniuk.duchessentials.DuchEssentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DuchLogger {
    
    public static void info(String message) {
        DuchEssentials.LOGGER.info(message);
    }
    
    public static void warn(String message) {
        DuchEssentials.LOGGER.warn(message);
    }
    
    public static void error(String message) {
        DuchEssentials.LOGGER.error(message);
    }
    
    public static void debug(String message) {
        DuchEssentials.LOGGER.debug(message);
    }
    
    public static class ModLogger {
        private final Logger logger;
        private final String modName;
        
        public ModLogger(String modId, String modName) {
            this.logger = LoggerFactory.getLogger(modId);
            this.modName = modName;
        }
        
        public void info(String message) {
            logger.info("[{}] {}", modName, message);
        }
        
        public void warn(String message) {
            logger.warn("[{}] {}", modName, message);
        }
        
        public void error(String message) {
            logger.error("[{}] {}", modName, message);
        }
        
        public void debug(String message) {
            logger.debug("[{}] {}", modName, message);
        }
    }
    
    public static ModLogger createLogger(String modId, String modName) {
        return new ModLogger(modId, modName);
    }
}
