package com.duuchniuk.duchessentials.utils;

import java.util.*;

public class CollectionUtils {
    
    private static final Random RANDOM = new Random();
    
    public static <T> boolean isNullOrEmpty(Collection<T> collection) {
        return collection == null || collection.isEmpty();
    }
    
    public static <T> T getRandomElement(List<T> list) {
        if (isNullOrEmpty(list)) return null;
        return list.get(RANDOM.nextInt(list.size()));
    }
    
    @SafeVarargs
    public static <T> List<T> listOf(T... elements) {
        return new ArrayList<>(Arrays.asList(elements));
    }
    
    public static <T> boolean containsAny(Collection<T> collection, Collection<T> elements) {
        if (isNullOrEmpty(collection) || isNullOrEmpty(elements)) return false;
        for (T element : elements) {
            if (collection.contains(element)) return true;
        }
        return false;
    }
    
    public static <T> boolean containsAll(Collection<T> collection, Collection<T> elements) {
        if (isNullOrEmpty(collection)) return false;
        return collection.containsAll(elements);
    }
    
    public static <T> T first(List<T> list) {
        if (isNullOrEmpty(list)) return null;
        return list.get(0);
    }
    
    public static <T> T last(List<T> list) {
        if (isNullOrEmpty(list)) return null;
        return list.get(list.size() - 1);
    }
}
