package com.duuchniuk.duchessentials.utils;

import java.util.Random;

public class MathUtils {
    
    private static final Random RANDOM = new Random();
    
    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
    
    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
    
    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
    
    public static double lerp(double start, double end, double alpha) {
        return start + (end - start) * alpha;
    }
    
    public static boolean inRange(int value, int min, int max) {
        return value >= min && value <= max;
    }
    
    public static boolean inRange(double value, double min, double max) {
        return value >= min && value <= max;
    }
    
    public static int randomInt(int min, int max) {
        return RANDOM.nextInt(max - min + 1) + min;
    }
    
    public static float randomFloat(float min, float max) {
        return min + RANDOM.nextFloat() * (max - min);
    }
    
    public static double randomDouble(double min, double max) {
        return min + RANDOM.nextDouble() * (max - min);
    }
    
    public static boolean approximately(double a, double b, double epsilon) {
        return Math.abs(a - b) < epsilon;
    }
    
    public static double getPercentage(double value, double max) {
        if (max == 0) return 0;
        return (value / max) * 100.0;
    }
}
