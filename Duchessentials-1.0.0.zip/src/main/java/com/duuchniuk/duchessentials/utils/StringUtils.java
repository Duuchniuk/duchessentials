package com.duuchniuk.duchessentials.utils;

public class StringUtils {
    
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.isEmpty();
    }
    
    public static String capitalize(String str) {
        if (isNullOrEmpty(str)) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }
    
    public static String toTitleCase(String str) {
        if (isNullOrEmpty(str)) return str;
        String[] words = str.split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            result.append(capitalize(word)).append(" ");
        }
        return result.toString().trim();
    }
    
    public static String repeat(String str, int times) {
        if (isNullOrEmpty(str) || times <= 0) return "";
        return str.repeat(times);
    }
    
    public static boolean equals(String str1, String str2) {
        if (str1 == null && str2 == null) return true;
        if (str1 == null || str2 == null) return false;
        return str1.equals(str2);
    }
}
