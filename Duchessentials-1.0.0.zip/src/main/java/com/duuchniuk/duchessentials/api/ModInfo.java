package com.duuchniuk.duchessentials.api;

public record ModInfo(String modId, String modName, String version, String author, String description) {
    
    @Override
    public String toString() {
        return modName + " v" + version + " by " + author;
    }
}
