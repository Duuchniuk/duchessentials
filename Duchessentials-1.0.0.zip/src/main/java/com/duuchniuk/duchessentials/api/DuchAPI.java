package com.duuchniuk.duchessentials.api;

import com.duuchniuk.duchessentials.core.DuchLogger;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class DuchAPI {
    
    private static final Map<String, ModInfo> REGISTERED_MODS = new HashMap<>();
    
    public static void registerMod(String modId, String modName, String version) {
        registerMod(modId, modName, version, "Unknown", "");
    }
    
    public static void registerMod(String modId, String modName, String version, String author, String description) {
        ModInfo info = new ModInfo(modId, modName, version, author, description);
        REGISTERED_MODS.put(modId, info);
        DuchLogger.info("Registered mod: " + modName + " v" + version + " by " + author);
    }
    
    public static Optional<ModInfo> getModInfo(String modId) {
        return Optional.ofNullable(REGISTERED_MODS.get(modId));
    }
    
    public static Map<String, ModInfo> getAllRegisteredMods() {
        return new HashMap<>(REGISTERED_MODS);
    }
    
    public static boolean isModRegistered(String modId) {
        return REGISTERED_MODS.containsKey(modId);
    }
}
